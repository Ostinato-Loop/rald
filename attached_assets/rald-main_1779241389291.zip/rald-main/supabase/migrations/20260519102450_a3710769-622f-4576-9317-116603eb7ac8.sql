
-- Phone OTP storage (custom OTP flow using Termii)
CREATE TABLE IF NOT EXISTS public.rald_phone_otps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone text NOT NULL,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  consumed_at timestamptz,
  attempts integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_rald_phone_otps_phone ON public.rald_phone_otps(phone, created_at DESC);

ALTER TABLE public.rald_phone_otps ENABLE ROW LEVEL SECURITY;

-- No client access; only service role (server fns) read/write
CREATE POLICY "no client access" ON public.rald_phone_otps
  FOR ALL TO authenticated USING (false) WITH CHECK (false);

-- Seed OTP provider settings row if missing
INSERT INTO public.rald_settings (key, value)
VALUES ('otp_provider', '{"provider":"termii","enabled":true,"sender_id":"RALD","api_key":""}'::jsonb)
ON CONFLICT (key) DO NOTHING;
