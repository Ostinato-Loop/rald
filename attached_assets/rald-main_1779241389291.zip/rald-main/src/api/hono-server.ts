import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";

export function createHono() {
  const app = new Hono();

  // Middleware
  app.use("*", logger());
  app.use(
    "/api/*",
    cors({
      origin: "*",
      allowMethods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
      allowHeaders: ["Content-Type", "Authorization"],
    }),
  );

  // Health check
  app.get("/api/health", (c) => {
    return c.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Auth endpoints
  app.post("/api/auth/phone/send-otp", async (c) => {
    try {
      const { phone } = await c.req.json();
      if (!phone) {
        return c.json({ error: "Phone number required" }, 400);
      }
      return c.json({ success: true, message: "OTP sent" });
    } catch (error) {
      console.error(error);
      return c.json({ error: "Failed to send OTP" }, 500);
    }
  });

  app.post("/api/auth/phone/verify-otp", async (c) => {
    try {
      const { phone, code } = await c.req.json();
      if (!phone || !code) {
        return c.json({ error: "Phone and code required" }, 400);
      }
      return c.json({ success: true, message: "OTP verified" });
    } catch (error) {
      console.error(error);
      return c.json({ error: "Failed to verify OTP" }, 500);
    }
  });

  // Developer API endpoints
  app.get("/api/developer/keys", (c) => {
    return c.json({ keys: [] });
  });

  app.post("/api/developer/keys", async (c) => {
    try {
      const body = await c.req.json();
      return c.json({ success: true, key: body }, 201);
    } catch (error) {
      console.error(error);
      return c.json({ error: "Failed to create API key" }, 500);
    }
  });

  // Wallet endpoints
  app.get("/api/wallet/balance", (c) => {
    return c.json({ balance: 0, currency: "NGN" });
  });

  app.get("/api/wallet/transactions", (c) => {
    return c.json({ transactions: [] });
  });

  // 404 handler
  app.notFound((c) => {
    return c.json({ error: "Not found" }, 404);
  });

  return app;
}
