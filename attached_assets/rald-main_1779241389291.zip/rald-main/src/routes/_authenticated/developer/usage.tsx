import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getUsageStats } from "@/lib/developer.functions";
import { TrendingUp, CheckCircle, XCircle, Zap } from "lucide-react";

export const Route = createFileRoute("/_authenticated/developer/usage")({
  component: UsagePage,
});

function UsagePage() {
  const statsFn = useServerFn(getUsageStats);
  const { data: stats, isLoading } = useQuery({ queryKey: ["dev-stats"], queryFn: () => statsFn() });

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="text-lg font-semibold">Usage Analytics</h2>
        <p className="text-sm text-muted-foreground mt-0.5">30-day rolling API usage metrics.</p>
      </div>

      {isLoading ? (
        <div className="text-sm text-muted-foreground">Loading…</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Total Requests" value={stats?.total?.toLocaleString() ?? "0"} icon={<TrendingUp className="h-5 w-5 text-primary" />} />
          <StatCard label="Successful" value={stats?.success?.toLocaleString() ?? "0"} icon={<CheckCircle className="h-5 w-5 text-green-500" />} />
          <StatCard label="Errors" value={stats?.errors?.toLocaleString() ?? "0"} icon={<XCircle className="h-5 w-5 text-red-500" />} />
          <StatCard label="Avg Latency" value={`${stats?.avgLatency ?? 0}ms`} icon={<Zap className="h-5 w-5 text-yellow-500" />} />
        </div>
      )}

      {stats && (
        <div className="rounded-lg border border-border bg-card p-5 space-y-4">
          <h3 className="text-sm font-semibold">Success Rate</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Success</span>
              <span className="font-mono font-medium">{stats.successRate.toFixed(1)}%</span>
            </div>
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-green-500 rounded-full" style={{ width: `${stats.successRate}%` }} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between mb-3">{icon}<span className="text-xs text-muted-foreground uppercase tracking-wider">{label}</span></div>
      <div className="text-2xl font-semibold font-mono">{value}</div>
    </div>
  );
}
