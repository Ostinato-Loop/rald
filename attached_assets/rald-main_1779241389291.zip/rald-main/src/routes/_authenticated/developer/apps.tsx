import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, ToggleLeft, ToggleRight, Copy, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { listApps, createApp, toggleApp } from "@/lib/developer.functions";

const ALL_SCOPES = ["openid", "profile", "phone", "email", "wallet:read", "auth:read"];

export const Route = createFileRoute("/_authenticated/developer/apps")({
  component: AppsPage,
});

function AppsPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listApps);
  const createFn = useServerFn(createApp);
  const toggleFn = useServerFn(toggleApp);

  const { data, isLoading } = useQuery({ queryKey: ["dev-apps"], queryFn: () => listFn() });

  const [showCreate, setShowCreate] = useState(false);
  const [credentials, setCredentials] = useState<{ clientId: string; clientSecret: string } | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", description: "", callbackUrls: "", webhookUrl: "", scopes: ["openid", "profile"] as string[] });

  const create = useMutation({
    mutationFn: () => createFn({
      data: {
        name: form.name,
        description: form.description || undefined,
        callbackUrls: form.callbackUrls.split("\n").map((u) => u.trim()).filter(Boolean),
        webhookUrl: form.webhookUrl || undefined,
        scopes: form.scopes,
      },
    }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["dev-apps"] });
      setCredentials({ clientId: res.client_id, clientSecret: res.clientSecret });
      setShowCreate(false);
      setForm({ name: "", description: "", callbackUrls: "", webhookUrl: "", scopes: ["openid", "profile"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggle = useMutation({
    mutationFn: ({ appId, isActive }: { appId: string; isActive: boolean }) => toggleFn({ data: { appId, isActive } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["dev-apps"] }); toast.success("App updated"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const toggleScope = (s: string) =>
    setForm((f) => ({ ...f, scopes: f.scopes.includes(s) ? f.scopes.filter((x) => x !== s) : [...f.scopes, s] }));

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Registered Apps</h2>
          <p className="text-sm text-muted-foreground mt-0.5">OAuth 2.0 / OIDC clients that federate with RALD.</p>
        </div>
        <Button onClick={() => setShowCreate(true)}><Plus className="h-4 w-4 mr-2" />Register App</Button>
      </div>

      {/* Credential reveal */}
      {credentials && (
        <div className="rounded-lg border border-green-500/30 bg-green-500/10 p-4 space-y-3">
          <p className="text-sm font-medium text-green-400">⚠ Save your client secret now — it cannot be retrieved again.</p>
          {[{ label: "Client ID", value: credentials.clientId, key: "id" }, { label: "Client Secret", value: credentials.clientSecret, key: "secret" }].map(({ label, value, key }) => (
            <div key={key} className="space-y-1">
              <p className="text-xs text-muted-foreground">{label}</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 font-mono text-xs bg-background rounded p-2 break-all">{value}</code>
                <Button size="sm" variant="outline" onClick={() => copy(value, key)}>
                  {copied === key ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          ))}
          <Button size="sm" variant="ghost" onClick={() => setCredentials(null)}>Dismiss</Button>
        </div>
      )}

      <div className="space-y-3">
        {isLoading && <div className="text-sm text-muted-foreground p-4">Loading…</div>}
        {!isLoading && (data?.apps ?? []).length === 0 && (
          <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            No apps registered yet. Create one to enable federated login.
          </div>
        )}
        {(data?.apps ?? []).map((app) => (
          <div key={app.id} className="rounded-lg border border-border bg-card p-5 flex items-start justify-between gap-4">
            <div className="space-y-2 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium">{app.name}</span>
                <Badge variant={app.is_active ? "default" : "secondary"} className="text-[10px]">{app.is_active ? "Active" : "Inactive"}</Badge>
              </div>
              <code className="text-xs text-muted-foreground font-mono">{app.client_id}</code>
              <div className="flex flex-wrap gap-1">
                {(app.scopes as string[]).map((s) => <Badge key={s} variant="outline" className="text-[10px]">{s}</Badge>)}
              </div>
              <div className="text-xs text-muted-foreground">
                Callbacks: {(app.callback_urls as string[]).join(", ")}
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={() => toggle.mutate({ appId: app.id, isActive: !app.is_active })} disabled={toggle.isPending}>
              {app.is_active ? <ToggleRight className="h-5 w-5 text-primary" /> : <ToggleLeft className="h-5 w-5 text-muted-foreground" />}
            </Button>
          </div>
        ))}
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Register New App</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5"><Label>App Name</Label><Input placeholder="Loop Messenger" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Description (optional)</Label><Input placeholder="Internal OstLoop messenger app" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} /></div>
            <div className="space-y-1.5">
              <Label>Callback URLs (one per line)</Label>
              <Textarea placeholder={"https://messenger.ostloop.ng/auth/callback\nhttp://localhost:3000/auth/callback"} value={form.callbackUrls} onChange={(e) => setForm((f) => ({ ...f, callbackUrls: e.target.value }))} rows={3} />
            </div>
            <div className="space-y-1.5"><Label>Webhook URL (optional)</Label><Input placeholder="https://messenger.ostloop.ng/webhooks/rald" value={form.webhookUrl} onChange={(e) => setForm((f) => ({ ...f, webhookUrl: e.target.value }))} /></div>
            <div className="space-y-1.5">
              <Label>Scopes</Label>
              <div className="flex flex-wrap gap-2">
                {ALL_SCOPES.map((s) => (
                  <button key={s} type="button" onClick={() => toggleScope(s)} className={`text-xs px-2.5 py-1 rounded border transition-colors ${form.scopes.includes(s) ? "bg-primary/15 border-primary/40 text-primary" : "border-border text-muted-foreground hover:border-foreground/40"}`}>{s}</button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button onClick={() => create.mutate()} disabled={create.isPending || !form.name || !form.callbackUrls.trim() || form.scopes.length === 0}>
              {create.isPending ? "Registering…" : "Register"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
