import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { listApiLogs } from "@/lib/developer.functions";

export const Route = createFileRoute("/_authenticated/developer/logs")({
  component: LogsPage,
});

function statusColor(code: number) {
  if (code < 300) return "bg-green-500/15 text-green-400 border-green-500/30";
  if (code < 400) return "bg-blue-500/15 text-blue-400 border-blue-500/30";
  if (code < 500) return "bg-yellow-500/15 text-yellow-400 border-yellow-500/30";
  return "bg-red-500/15 text-red-400 border-red-500/30";
}

function LogsPage() {
  const listFn = useServerFn(listApiLogs);
  const [limit, setLimit] = useState(50);
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["api-logs", limit],
    queryFn: () => listFn({ data: { limit } }),
    refetchInterval: 30_000,
  });

  return (
    <div className="max-w-6xl space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Request Logs</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Live stream of API calls — refreshes every 30s.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            className="text-sm border border-border rounded px-2 py-1.5 bg-background"
            value={limit}
            onChange={(e) => setLimit(Number(e.target.value))}
          >
            <option value={50}>50 rows</option>
            <option value={100}>100 rows</option>
            <option value={200}>200 rows</option>
          </select>
          <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${isFetching ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-xs font-mono">
          <thead className="bg-muted/40 text-muted-foreground uppercase tracking-wider text-[10px]">
            <tr>
              <th className="text-left p-3 font-medium">Time</th>
              <th className="text-left p-3 font-medium">Method</th>
              <th className="text-left p-3 font-medium">Endpoint</th>
              <th className="text-left p-3 font-medium">Status</th>
              <th className="text-left p-3 font-medium">Latency</th>
              <th className="text-left p-3 font-medium">IP</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={6} className="p-6 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!isLoading && (data?.logs ?? []).length === 0 && (
              <tr>
                <td colSpan={6} className="p-6 text-center text-muted-foreground">
                  No requests logged yet.
                </td>
              </tr>
            )}
            {(data?.logs ?? []).map((log) => (
              <tr key={log.id} className="border-t border-border hover:bg-muted/20">
                <td className="p-3 text-muted-foreground whitespace-nowrap">
                  {new Date(log.created_at).toLocaleTimeString()}
                </td>
                <td className="p-3">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      log.method === "GET"
                        ? "text-blue-400"
                        : log.method === "POST"
                          ? "text-green-400"
                          : log.method === "DELETE"
                            ? "text-red-400"
                            : "text-yellow-400"
                    }`}
                  >
                    {log.method}
                  </span>
                </td>
                <td className="p-3 text-foreground max-w-[240px] truncate">{log.endpoint}</td>
                <td className="p-3">
                  <span
                    className={`px-1.5 py-0.5 rounded border text-[10px] font-bold ${statusColor(log.status_code ?? 0)}`}
                  >
                    {log.status_code ?? "—"}
                  </span>
                </td>
                <td className="p-3 text-muted-foreground">
                  {log.duration_ms != null ? `${log.duration_ms}ms` : "—"}
                </td>
                <td className="p-3 text-muted-foreground">{log.ip_address ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
