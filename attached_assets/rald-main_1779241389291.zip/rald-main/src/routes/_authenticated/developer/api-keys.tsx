import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, RefreshCcw, Copy, Eye, EyeOff, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { listApiKeys, createApiKey, revokeApiKey, rotateApiKey } from "@/lib/developer.functions";

const SCOPES = ["auth:read", "auth:write", "wallet:read", "wallet:write", "admin:read", "webhooks:write"];

export const Route = createFileRoute("/_authenticated/developer/api-keys")({
  component: ApiKeysPage,
});

function ApiKeysPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listApiKeys);
  const createFn = useServerFn(createApiKey);
  const revokeFn = useServerFn(revokeApiKey);
  const rotateFn = useServerFn(rotateApiKey);

  const { data, isLoading } = useQuery({ queryKey: ["api-keys"], queryFn: () => listFn() });

  const [showCreate, setShowCreate] = useState(false);
  const [newKey, setNewKey] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", environment: "test" as "test" | "live", scopes: [] as string[], expiresInDays: "" });
  const [copied, setCopied] = useState(false);

  const create = useMutation({
    mutationFn: () => createFn({ data: { name: form.name, environment: form.environment, scopes: form.scopes, expiresInDays: form.expiresInDays ? parseInt(form.expiresInDays) : undefined } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["api-keys"] });
      setNewKey(res.key);
      setShowCreate(false);
      setForm({ name: "", environment: "test", scopes: [], expiresInDays: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const revoke = useMutation({
    mutationFn: (keyId: string) => revokeFn({ data: { keyId } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["api-keys"] }); toast.success("Key revoked"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const rotate = useMutation({
    mutationFn: (keyId: string) => rotateFn({ data: { keyId } }),
    onSuccess: (res) => { qc.invalidateQueries({ queryKey: ["api-keys"] }); setNewKey(res.key); toast.success("Key rotated — save your new key"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleScope = (scope: string) =>
    setForm((f) => ({ ...f, scopes: f.scopes.includes(scope) ? f.scopes.filter((s) => s !== scope) : [...f.scopes, scope] }));

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">API Keys</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Scoped keys for programmatic access to RALD APIs.</p>
        </div>
        <Button onClick={() => setShowCreate(true)}><Plus className="h-4 w-4 mr-2" />New Key</Button>
      </div>

      {/* New key reveal */}
      {newKey && (
        <div className="rounded-lg border border-green-500/30 bg-green-500/10 p-4 space-y-3">
          <p className="text-sm font-medium text-green-400">⚠ Copy this key now — it will never be shown again.</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 font-mono text-xs bg-background rounded p-2 break-all">{newKey}</code>
            <Button size="sm" variant="outline" onClick={() => copyKey(newKey)}>
              {copied ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>
          <Button size="sm" variant="ghost" onClick={() => setNewKey(null)}>Dismiss</Button>
        </div>
      )}

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs text-muted-foreground uppercase tracking-wider">
            <tr>
              <th className="text-left p-3 font-medium">Name</th>
              <th className="text-left p-3 font-medium">Prefix</th>
              <th className="text-left p-3 font-medium">Env</th>
              <th className="text-left p-3 font-medium">Scopes</th>
              <th className="text-left p-3 font-medium">Expires</th>
              <th className="text-right p-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">Loading…</td></tr>}
            {!isLoading && (data?.keys ?? []).length === 0 && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No API keys yet. Create one to get started.</td></tr>}
            {(data?.keys ?? []).map((k) => (
              <tr key={k.id} className="border-t border-border">
                <td className="p-3 font-medium">{k.name}</td>
                <td className="p-3 font-mono text-xs text-muted-foreground">{k.prefix}…</td>
                <td className="p-3"><Badge variant={k.environment === "live" ? "default" : "secondary"} className="text-[10px]">{k.environment}</Badge></td>
                <td className="p-3"><div className="flex flex-wrap gap-1">{(k.scopes as string[]).map((s) => <Badge key={s} variant="outline" className="text-[10px]">{s}</Badge>)}</div></td>
                <td className="p-3 text-xs text-muted-foreground">{k.expires_at ? new Date(k.expires_at).toLocaleDateString() : "Never"}</td>
                <td className="p-3 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button size="sm" variant="ghost" onClick={() => rotate.mutate(k.id)} disabled={rotate.isPending} title="Rotate">
                      <RefreshCcw className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => revoke.mutate(k.id)} disabled={revoke.isPending} className="text-destructive hover:text-destructive" title="Revoke">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create API Key</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5"><Label>Name</Label><Input placeholder="My service key" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} /></div>
            <div className="space-y-1.5">
              <Label>Environment</Label>
              <Select value={form.environment} onValueChange={(v) => setForm((f) => ({ ...f, environment: v as "test" | "live" }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="test">Test</SelectItem><SelectItem value="live">Live</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Scopes</Label>
              <div className="flex flex-wrap gap-2">
                {SCOPES.map((s) => (
                  <button key={s} type="button" onClick={() => toggleScope(s)} className={`text-xs px-2.5 py-1 rounded border transition-colors ${form.scopes.includes(s) ? "bg-primary/15 border-primary/40 text-primary" : "border-border text-muted-foreground hover:border-foreground/40"}`}>{s}</button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5"><Label>Expires in (days, optional)</Label><Input type="number" placeholder="90" value={form.expiresInDays} onChange={(e) => setForm((f) => ({ ...f, expiresInDays: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button onClick={() => create.mutate()} disabled={create.isPending || !form.name || form.scopes.length === 0}>
              {create.isPending ? "Creating…" : "Create Key"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
