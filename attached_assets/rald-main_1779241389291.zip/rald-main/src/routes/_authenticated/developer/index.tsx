import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getUsageStats, listApiKeys, listApps } from "@/lib/developer.functions";
import { KeyRound, AppWindow, ScrollText, TrendingUp, CheckCircle, XCircle, Zap } from "lucide-react";

export const Route = createFileRoute("/_authenticated/developer/")({
  component: DeveloperOverviewPage,
});

function DeveloperOverviewPage() {
  const statsFn = useServerFn(getUsageStats);
  const keysFn = useServerFn(listApiKeys);
  const appsFn = useServerFn(listApps);

  const { data: stats } = useQuery({ queryKey: ["dev-stats"], queryFn: () => statsFn() });
  const { data: keysData } = useQuery({ queryKey: ["api-keys"], queryFn: () => keysFn() });
  const { data: appsData } = useQuery({ queryKey: ["dev-apps"], queryFn: () => appsFn() });

  const activeKeys = (keysData?.keys ?? []).filter((k) => !k.revoked_at).length;
  const activeApps = (appsData?.apps ?? []).filter((a) => a.is_active).length;

  return (
    <div className="max-w-5xl space-y-8">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Requests (30d)" value={stats?.total?.toLocaleString() ?? "—"} icon={<TrendingUp className="h-4 w-4" />} />
        <StatCard label="Success rate" value={stats ? `${stats.successRate.toFixed(1)}%` : "—"} icon={<CheckCircle className="h-4 w-4 text-green-500" />} />
        <StatCard label="Avg latency" value={stats ? `${stats.avgLatency}ms` : "—"} icon={<Zap className="h-4 w-4 text-yellow-500" />} />
        <StatCard label="Errors (30d)" value={stats?.errors?.toLocaleString() ?? "—"} icon={<XCircle className="h-4 w-4 text-red-500" />} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <QuickLink to="/developer/api-keys" icon={<KeyRound className="h-5 w-5" />} label="API Keys" description={`${activeKeys} active key${activeKeys !== 1 ? "s" : ""}`} />
        <QuickLink to="/developer/apps" icon={<AppWindow className="h-5 w-5" />} label="Apps" description={`${activeApps} registered app${activeApps !== 1 ? "s" : ""}`} />
        <QuickLink to="/developer/logs" icon={<ScrollText className="h-5 w-5" />} label="Request Logs" description="Inspect recent API calls" />
      </div>

      <div className="rounded-lg border border-border bg-card p-5 space-y-3">
        <h3 className="font-semibold text-sm">Quick start</h3>
        <ol className="text-sm text-muted-foreground space-y-2 list-decimal list-inside">
          <li>Register an <Link to="/developer/apps" className="text-primary underline-offset-4 hover:underline">App</Link> to get a client ID &amp; secret.</li>
          <li>Create a scoped <Link to="/developer/api-keys" className="text-primary underline-offset-4 hover:underline">API Key</Link> for your environment.</li>
          <li>Include <code className="bg-muted px-1 rounded text-xs">Authorization: Bearer &lt;key&gt;</code> in every request.</li>
          <li>Monitor usage in <Link to="/developer/logs" className="text-primary underline-offset-4 hover:underline">Logs</Link> and <Link to="/developer/usage" className="text-primary underline-offset-4 hover:underline">Usage</Link>.</li>
        </ol>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-muted-foreground uppercase tracking-wider">{label}</span>
        {icon}
      </div>
      <div className="text-2xl font-semibold font-mono">{value}</div>
    </div>
  );
}

function QuickLink({ to, icon, label, description }: { to: string; icon: React.ReactNode; label: string; description: string }) {
  return (
    <Link to={to} className="rounded-lg border border-border bg-card p-5 flex items-start gap-4 hover:bg-muted/40 transition-colors">
      <div className="h-9 w-9 rounded bg-primary/15 text-primary flex items-center justify-center shrink-0">{icon}</div>
      <div>
        <div className="font-medium">{label}</div>
        <div className="text-sm text-muted-foreground mt-0.5">{description}</div>
      </div>
    </Link>
  );
}
