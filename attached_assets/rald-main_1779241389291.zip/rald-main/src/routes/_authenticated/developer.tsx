import { createFileRoute, Link, Outlet, useMatchRoute } from "@tanstack/react-router";
import { KeyRound, AppWindow, ScrollText, BarChart2, Boxes } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/developer")({
  component: DeveloperLayout,
});

type NavItem = {
  to: string;
  label: string;
  icon: LucideIcon;
  /** When true, only match this exact path (not sub-paths). */
  fuzzy?: boolean;
};

const NAV: NavItem[] = [
  { to: "/developer", label: "Overview", icon: Boxes, fuzzy: false },
  { to: "/developer/apps", label: "Apps", icon: AppWindow },
  { to: "/developer/api-keys", label: "API Keys", icon: KeyRound },
  { to: "/developer/logs", label: "Logs", icon: ScrollText },
  { to: "/developer/usage", label: "Usage", icon: BarChart2 },
];

function DeveloperLayout() {
  const matchRoute = useMatchRoute();
  return (
    <div className="flex flex-col min-h-full">
      <div className="border-b border-border bg-card/50 px-8 pt-8 pb-0">
        <h1 className="text-2xl font-semibold mb-4">Developer Platform</h1>
        <nav className="flex gap-1 -mb-px">
          {NAV.map(({ to, label, icon: Icon, fuzzy }) => {
            const active = matchRoute({ to: to as never, fuzzy: fuzzy ?? true });
            return (
              <Link
                key={to}
                to={to as never}
                className={cn(
                  "flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors",
                  active
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:border-border",
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="flex-1 p-8">
        <Outlet />
      </div>
    </div>
  );
}
