import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useInfiniteQuery } from "@tanstack/react-query";
import { listTransactions } from "@/lib/wallet.functions";
import { ArrowDownLeft, ArrowUpRight, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/wallet/transactions")({
  component: TransactionsPage,
});

function naira(minor: number) {
  return `₦${(minor / 100).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;
}

const TYPE_ICON: Record<string, React.ReactNode> = {
  credit: <ArrowDownLeft className="h-4 w-4 text-green-400" />,
  debit: <ArrowUpRight className="h-4 w-4 text-red-400" />,
  escrow_lock: <Clock className="h-4 w-4 text-orange-400" />,
  escrow_release: <ArrowDownLeft className="h-4 w-4 text-blue-400" />,
};

function TransactionsPage() {
  const listFn = useServerFn(listTransactions);
  const PAGE = 50;

  const { data, fetchNextPage, hasNextPage, isLoading, isFetchingNextPage } = useInfiniteQuery({
    queryKey: ["wallet-transactions"],
    queryFn: ({ pageParam = 0 }) => listFn({ data: { limit: PAGE, offset: pageParam } }),
    getNextPageParam: (last, pages) => {
      const loaded = pages.reduce((s, p) => s + p.transactions.length, 0);
      return loaded < last.total ? loaded : undefined;
    },
    initialPageParam: 0,
  });

  const txns = data?.pages.flatMap((p) => p.transactions) ?? [];
  const total = data?.pages[0]?.total ?? 0;

  return (
    <div className="max-w-3xl space-y-4">
      <div>
        <h2 className="text-lg font-semibold">Transaction History</h2>
        <p className="text-sm text-muted-foreground mt-0.5">{total} total transactions on your NGN wallet.</p>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden divide-y divide-border">
        {isLoading && <div className="p-6 text-center text-sm text-muted-foreground">Loading…</div>}
        {!isLoading && txns.length === 0 && (
          <div className="p-8 text-center text-sm text-muted-foreground">No transactions yet.</div>
        )}
        {txns.map((txn) => (
          <div key={txn.id} className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-muted flex items-center justify-center">
                {TYPE_ICON[txn.type] ?? <ArrowUpRight className="h-4 w-4 text-muted-foreground" />}
              </div>
              <div>
                <div className="text-sm font-medium">{txn.description ?? txn.type}</div>
                <div className="text-xs text-muted-foreground font-mono mt-0.5">{new Date(txn.created_at).toLocaleString()}</div>
              </div>
            </div>
            <div className="text-right">
              <div className={`font-mono font-semibold text-sm ${txn.type === "credit" || txn.type === "escrow_release" ? "text-green-400" : "text-foreground"}`}>
                {txn.type === "credit" || txn.type === "escrow_release" ? "+" : "-"}{naira(txn.amount_minor)}
              </div>
              <Badge variant={txn.status === "completed" ? "default" : txn.status === "pending" ? "secondary" : "destructive"} className="text-[10px] mt-1">
                {txn.status}
              </Badge>
            </div>
          </div>
        ))}
      </div>

      {hasNextPage && (
        <div className="flex justify-center">
          <Button variant="outline" onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>
            {isFetchingNextPage ? "Loading…" : "Load more"}
          </Button>
        </div>
      )}
    </div>
  );
}
