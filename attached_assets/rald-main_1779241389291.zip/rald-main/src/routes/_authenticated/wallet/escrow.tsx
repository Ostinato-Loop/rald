import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, CheckCircle, AlertTriangle, Clock, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { listEscrows, createEscrow, releaseEscrow, disputeEscrow } from "@/lib/wallet.functions";
import { useSession } from "@/hooks/use-session";

export const Route = createFileRoute("/_authenticated/wallet/escrow")({
  component: EscrowPage,
});

function naira(minor: number) {
  return `₦${(minor / 100).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;
}

const STATUS_BADGE: Record<string, string> = {
  pending: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
  released: "bg-green-500/15 text-green-400 border-green-500/30",
  disputed: "bg-red-500/15 text-red-400 border-red-500/30",
  cancelled: "bg-muted text-muted-foreground",
};

function EscrowPage() {
  const qc = useQueryClient();
  const { user } = useSession();
  const listFn = useServerFn(listEscrows);
  const createFn = useServerFn(createEscrow);
  const releaseFn = useServerFn(releaseEscrow);
  const disputeFn = useServerFn(disputeEscrow);

  const { data, isLoading } = useQuery({ queryKey: ["escrows"], queryFn: () => listFn() });

  const [showCreate, setShowCreate] = useState(false);
  const [showDispute, setShowDispute] = useState<string | null>(null);
  const [form, setForm] = useState({ sellerId: "", amountNaira: "", title: "", description: "" });
  const [disputeReason, setDisputeReason] = useState("");

  const create = useMutation({
    mutationFn: () => createFn({ data: { sellerId: form.sellerId, amountNaira: parseFloat(form.amountNaira), title: form.title, description: form.description || undefined } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["escrows"] }); qc.invalidateQueries({ queryKey: ["wallet"] }); setShowCreate(false); setForm({ sellerId: "", amountNaira: "", title: "", description: "" }); toast.success("Escrow created — funds locked"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const release = useMutation({
    mutationFn: (escrowId: string) => releaseFn({ data: { escrowId } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["escrows"] }); qc.invalidateQueries({ queryKey: ["wallet"] }); toast.success("Funds released to seller"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const dispute = useMutation({
    mutationFn: ({ escrowId, reason }: { escrowId: string; reason: string }) => disputeFn({ data: { escrowId, reason } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["escrows"] }); setShowDispute(null); setDisputeReason(""); toast.success("Dispute raised — a moderator will review"); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Escrow</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Secure peer-to-peer transactions with dispute protection.</p>
        </div>
        <Button onClick={() => setShowCreate(true)}><Plus className="h-4 w-4 mr-2" />New Escrow</Button>
      </div>

      <div className="space-y-3">
        {isLoading && <div className="text-sm text-muted-foreground p-4">Loading…</div>}
        {!isLoading && (data?.escrows ?? []).length === 0 && (
          <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            No escrows yet. Create one to securely transact with another party.
          </div>
        )}
        {(data?.escrows ?? []).map((e) => {
          const isBuyer = e.buyer_id === user?.id;
          return (
            <div key={e.id} className="rounded-lg border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium">{e.title}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded border font-medium ${STATUS_BADGE[e.status] ?? ""}`}>{e.status}</span>
                    {isBuyer && <Badge variant="outline" className="text-[10px]">You are buyer</Badge>}
                    {!isBuyer && <Badge variant="outline" className="text-[10px]">You are seller</Badge>}
                  </div>
                  <div className="text-2xl font-bold font-mono">{naira(e.amount_minor)}</div>
                  {e.description && <p className="text-sm text-muted-foreground">{e.description}</p>}
                  <div className="text-xs text-muted-foreground font-mono">Created {new Date(e.created_at).toLocaleDateString()}</div>
                </div>
                {e.status === "pending" && isBuyer && (
                  <div className="flex gap-2 shrink-0">
                    <Button size="sm" onClick={() => release.mutate(e.id)} disabled={release.isPending}>
                      <CheckCircle className="h-3.5 w-3.5 mr-1.5" />Release
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setShowDispute(e.id)} className="text-red-400 border-red-400/30 hover:bg-red-500/10">
                      <AlertTriangle className="h-3.5 w-3.5 mr-1.5" />Dispute
                    </Button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create Escrow</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5"><Label>Seller User ID</Label><Input placeholder="UUID of the recipient" value={form.sellerId} onChange={(e) => setForm((f) => ({ ...f, sellerId: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Amount (₦)</Label><Input type="number" placeholder="50000" value={form.amountNaira} onChange={(e) => setForm((f) => ({ ...f, amountNaira: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Title</Label><Input placeholder="Freelance design work — milestone 1" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>Description (optional)</Label><Textarea placeholder="Describe what this escrow covers…" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button onClick={() => create.mutate()} disabled={create.isPending || !form.sellerId || !form.amountNaira || !form.title}>
              {create.isPending ? "Creating…" : "Lock Funds & Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dispute Dialog */}
      <Dialog open={!!showDispute} onOpenChange={(open) => { if (!open) { setShowDispute(null); setDisputeReason(""); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>Raise Dispute</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-sm text-muted-foreground">Describe the issue clearly. A RALD moderator will review and resolve within 72 hours.</p>
            <Textarea placeholder="Explain what went wrong…" value={disputeReason} onChange={(e) => setDisputeReason(e.target.value)} rows={4} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowDispute(null); setDisputeReason(""); }}>Cancel</Button>
            <Button variant="destructive" onClick={() => showDispute && dispute.mutate({ escrowId: showDispute, reason: disputeReason })} disabled={dispute.isPending || disputeReason.trim().length < 10}>
              {dispute.isPending ? "Submitting…" : "Submit Dispute"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
