import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getOrCreateWallet, listEscrows } from "@/lib/wallet.functions";
import { Wallet, ArrowDownLeft, ArrowUpRight, HandCoins, AlertCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/wallet/")({
  component: WalletOverviewPage,
});

function naira(minor: number) {
  return `₦${(minor / 100).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;
}

function WalletOverviewPage() {
  const walletFn = useServerFn(getOrCreateWallet);
  const escrowsFn = useServerFn(listEscrows);

  const { data: walletData, isLoading } = useQuery({ queryKey: ["wallet"], queryFn: () => walletFn() });
  const { data: escrowData } = useQuery({ queryKey: ["escrows"], queryFn: () => escrowsFn() });

  const wallet = walletData?.wallet;
  const pendingEscrows = (escrowData?.escrows ?? []).filter((e) => e.status === "pending").length;
  const disputedEscrows = (escrowData?.escrows ?? []).filter((e) => e.status === "disputed").length;

  return (
    <div className="max-w-3xl space-y-6">
      {/* Balance card */}
      <div className="rounded-xl border border-border bg-gradient-to-br from-primary/10 to-card p-6">
        {isLoading ? (
          <div className="text-muted-foreground text-sm">Loading wallet…</div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                <Wallet className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider">NGN Wallet</div>
                <div className="text-3xl font-bold font-mono">{wallet ? naira(wallet.balance_minor) : "₦0.00"}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border/50">
              <div>
                <div className="text-xs text-muted-foreground">Pending</div>
                <div className="font-mono font-medium text-yellow-400">{wallet ? naira(wallet.pending_minor) : "₦0.00"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Locked (escrow)</div>
                <div className="font-mono font-medium text-orange-400">{wallet ? naira(wallet.locked_minor) : "₦0.00"}</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-4">
        <Link to="/wallet/transactions" className="rounded-lg border border-border bg-card p-4 flex items-center gap-3 hover:bg-muted/40 transition-colors">
          <div className="h-9 w-9 rounded bg-blue-500/15 text-blue-400 flex items-center justify-center"><History className="h-5 w-5" /></div>
          <div><div className="font-medium text-sm">Transactions</div><div className="text-xs text-muted-foreground">View full history</div></div>
        </Link>
        <Link to="/wallet/escrow" className="rounded-lg border border-border bg-card p-4 flex items-center gap-3 hover:bg-muted/40 transition-colors">
          <div className="h-9 w-9 rounded bg-primary/15 text-primary flex items-center justify-center"><HandCoins className="h-5 w-5" /></div>
          <div>
            <div className="font-medium text-sm">Escrow</div>
            <div className="text-xs text-muted-foreground">
              {pendingEscrows} pending{disputedEscrows > 0 ? `, ${disputedEscrows} disputed` : ""}
            </div>
          </div>
        </Link>
      </div>

      {disputedEscrows > 0 && (
        <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-4 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-yellow-400 shrink-0 mt-0.5" />
          <div className="text-sm text-yellow-300">
            You have <strong>{disputedEscrows}</strong> disputed escrow{disputedEscrows > 1 ? "s" : ""} that need resolution. <Link to="/wallet/escrow" className="underline">Review now</Link>.
          </div>
        </div>
      )}
    </div>
  );
}

function History(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
      <path d="M12 7v5l4 2" />
    </svg>
  );
}
