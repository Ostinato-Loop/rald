import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getMyProfile, updateMyProfile } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const fetchProfile = useServerFn(getMyProfile);
  const update = useServerFn(updateMyProfile);
  const qc = useQueryClient();

  const { data } = useQuery({ queryKey: ["me"], queryFn: () => fetchProfile() });
  const [fullName, setFullName] = useState<string>("");
  const [avatarUrl, setAvatarUrl] = useState<string>("");

  // Hydrate when data arrives
  if (data?.profile && fullName === "" && avatarUrl === "") {
    if (data.profile.full_name) setFullName(data.profile.full_name);
    if (data.profile.avatar_url) setAvatarUrl(data.profile.avatar_url);
  }

  const mutation = useMutation({
    mutationFn: () =>
      update({
        data: {
          full_name: fullName.trim() || null,
          avatar_url: avatarUrl.trim() || null,
        },
      }),
    onSuccess: () => {
      toast.success("Profile updated");
      qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="p-8 max-w-2xl mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-semibold">My profile</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Update your display name and avatar. Phone number can only be changed by re-verifying.
        </p>
      </header>

      <div className="rounded-lg border border-border bg-card p-6 space-y-5">
        <div className="space-y-2">
          <Label>Email</Label>
          <Input value={data?.profile?.email ?? ""} disabled />
        </div>
        <div className="space-y-2">
          <Label htmlFor="full_name">Full name</Label>
          <Input
            id="full_name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Chinedu Okeke"
            maxLength={120}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="avatar_url">Avatar URL</Label>
          <Input
            id="avatar_url"
            value={avatarUrl}
            onChange={(e) => setAvatarUrl(e.target.value)}
            placeholder="https://..."
            maxLength={500}
          />
        </div>
        <Button onClick={() => mutation.mutate()} disabled={mutation.isPending}>
          {mutation.isPending ? "Saving..." : "Save changes"}
        </Button>
      </div>
    </div>
  );
}
