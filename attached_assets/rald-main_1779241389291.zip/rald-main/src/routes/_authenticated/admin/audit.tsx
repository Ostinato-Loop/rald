import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { adminListAuditLogs } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/audit")({
  component: AuditPage,
});

function AuditPage() {
  const listFn = useServerFn(adminListAuditLogs);
  const [filter, setFilter] = useState("");
  const [submitted, setSubmitted] = useState("");
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["audit", submitted],
    queryFn: () => listFn({ data: { action: submitted || undefined, limit: 200 } }),
  });

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Audit logs</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Immutable trail of every login, role change and configuration update.
          </p>
        </div>
        <Button variant="outline" onClick={() => refetch()} disabled={isFetching}>
          {isFetching ? "Refreshing…" : "Refresh"}
        </Button>
      </header>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          setSubmitted(filter.trim());
        }}
        className="relative max-w-md"
      >
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Filter by action (e.g. role.granted, otp.requested)"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
      </form>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs text-muted-foreground uppercase tracking-wider">
            <tr>
              <th className="text-left p-3 font-medium">Time</th>
              <th className="text-left p-3 font-medium">Action</th>
              <th className="text-left p-3 font-medium">Resource</th>
              <th className="text-left p-3 font-medium">Actor</th>
              <th className="text-left p-3 font-medium">Metadata</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!isLoading && (data?.logs ?? []).length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-muted-foreground">
                  No audit events yet.
                </td>
              </tr>
            )}
            {(data?.logs ?? []).map((l) => (
              <tr key={l.id} className="border-t border-border align-top">
                <td className="p-3 text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(l.created_at).toLocaleString()}
                </td>
                <td className="p-3 font-medium">{l.action}</td>
                <td className="p-3 text-xs text-muted-foreground">
                  {l.resource_type ? `${l.resource_type}` : "—"}
                  {l.resource_id ? (
                    <div className="font-mono text-[10px] opacity-70 truncate max-w-[180px]">
                      {l.resource_id}
                    </div>
                  ) : null}
                </td>
                <td className="p-3 text-xs font-mono opacity-70 truncate max-w-[180px]">
                  {l.actor_id ?? "system"}
                </td>
                <td className="p-3">
                  <pre className="text-[10px] font-mono text-muted-foreground bg-muted/40 rounded p-2 max-w-md overflow-x-auto">
                    {JSON.stringify(l.metadata, null, 2)}
                  </pre>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
