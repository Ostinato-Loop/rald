import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { adminGetOtpProvider, adminSetOtpProvider } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/otp")({
  component: OtpProviderPage,
});

function OtpProviderPage() {
  const getFn = useServerFn(adminGetOtpProvider);
  const setFn = useServerFn(adminSetOtpProvider);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({ queryKey: ["otp-provider"], queryFn: () => getFn() });

  const [provider, setProvider] = useState<"termii" | "twilio" | "africastalking">("termii");
  const [enabled, setEnabled] = useState(true);
  const [senderId, setSenderId] = useState("");
  const [apiKey, setApiKey] = useState("");

  useEffect(() => {
    if (data) {
      setProvider((data.provider as typeof provider) ?? "termii");
      setEnabled(data.enabled);
      setSenderId(data.sender_id);
    }
  }, [data]);

  const save = useMutation({
    mutationFn: () =>
      setFn({
        data: { provider, enabled, sender_id: senderId, api_key: apiKey || undefined },
      }),
    onSuccess: () => {
      toast.success("OTP provider updated");
      setApiKey("");
      qc.invalidateQueries({ queryKey: ["otp-provider"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) {
    return <div className="p-8 text-muted-foreground text-sm">Loading…</div>;
  }

  return (
    <div className="p-8 max-w-2xl mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-semibold">OTP provider</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Switch SMS providers without redeploying. Keys are stored encrypted in the database
          (service-role-only read).
        </p>
      </header>

      <div className="rounded-lg border border-border bg-card p-6 space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-medium text-sm">Provider enabled</div>
            <div className="text-xs text-muted-foreground">
              Disable to stop sending real SMS (dev codes will appear in server logs).
            </div>
          </div>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
        </div>

        <div className="space-y-2">
          <Label>Provider</Label>
          <Select value={provider} onValueChange={(v) => setProvider(v as typeof provider)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="termii">Termii (Nigeria)</SelectItem>
              <SelectItem value="twilio">Twilio Verify</SelectItem>
              <SelectItem value="africastalking">Africa's Talking</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="sender">Sender ID</Label>
          <Input
            id="sender"
            value={senderId}
            onChange={(e) => setSenderId(e.target.value)}
            placeholder="RALD"
            maxLength={20}
          />
          <p className="text-xs text-muted-foreground">
            Termii: pre-approved sender ID. Max 11 alphanumeric characters.
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="api_key">
            API key{" "}
            {data?.api_key_set && (
              <span className="text-xs text-success font-normal">(configured)</span>
            )}
          </Label>
          <Input
            id="api_key"
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder={data?.api_key_set ? "•••••••• (leave blank to keep)" : "Paste new API key"}
          />
          <p className="text-xs text-muted-foreground">
            Get yours at{" "}
            <a
              href="https://accounts.termii.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              accounts.termii.com
            </a>
            . Leave blank to keep the existing key.
          </p>
        </div>

        <div className="pt-2 flex items-center justify-between">
          <div className="text-xs text-muted-foreground">
            {data?.updated_at
              ? `Last updated ${new Date(data.updated_at).toLocaleString()}`
              : "Never updated"}
          </div>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>
            {save.isPending ? "Saving…" : "Save provider settings"}
          </Button>
        </div>
      </div>
    </div>
  );
}
