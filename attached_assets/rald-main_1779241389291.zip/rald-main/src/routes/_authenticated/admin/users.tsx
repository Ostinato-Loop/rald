import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Search, UserCheck, UserX, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  adminListUsers,
  adminSetUserRole,
  adminSetUserActive,
} from "@/lib/admin.functions";

const ROLES = [
  "super_admin",
  "admin",
  "moderator",
  "developer",
  "verified_user",
  "business",
  "finance_admin",
] as const;

export const Route = createFileRoute("/_authenticated/admin/users")({
  component: UsersPage,
});

function UsersPage() {
  const listFn = useServerFn(adminListUsers);
  const setRoleFn = useServerFn(adminSetUserRole);
  const setActiveFn = useServerFn(adminSetUserActive);
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [submitted, setSubmitted] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["admin-users", submitted],
    queryFn: () => listFn({ data: { search: submitted || undefined, limit: 50 } }),
  });

  const setRole = useMutation({
    mutationFn: (v: { user_id: string; role: (typeof ROLES)[number]; grant: boolean }) =>
      setRoleFn({ data: v }),
    onSuccess: () => {
      toast.success("Role updated");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setActive = useMutation({
    mutationFn: (v: { user_id: string; is_active: boolean }) => setActiveFn({ data: v }),
    onSuccess: () => {
      toast.success("Status updated");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-semibold">Users & roles</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage all RALD identities. Grant or revoke roles, activate or deactivate accounts.
        </p>
      </header>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          setSubmitted(search.trim());
        }}
        className="flex gap-2"
      >
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search by email or name…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button type="submit" variant="secondary">
          Search
        </Button>
      </form>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs text-muted-foreground uppercase tracking-wider">
            <tr>
              <th className="text-left p-3 font-medium">User</th>
              <th className="text-left p-3 font-medium">Roles</th>
              <th className="text-left p-3 font-medium">Status</th>
              <th className="text-right p-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!isLoading && (data?.users ?? []).length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-muted-foreground">
                  No users found.
                </td>
              </tr>
            )}
            {(data?.users ?? []).map((u) => (
              <tr key={u.user_id} className="border-t border-border align-top">
                <td className="p-3">
                  <div className="font-medium">{u.full_name ?? "—"}</div>
                  <div className="text-xs text-muted-foreground">{u.email}</div>
                </td>
                <td className="p-3">
                  <div className="flex flex-wrap gap-1">
                    {u.roles.length === 0 && <span className="text-xs text-muted-foreground">none</span>}
                    {u.roles.map((r) => (
                      <button
                        key={r}
                        onClick={() =>
                          setRole.mutate({
                            user_id: u.user_id,
                            role: r as (typeof ROLES)[number],
                            grant: false,
                          })
                        }
                        className="group inline-flex items-center gap-1 rounded bg-primary/15 text-primary text-[11px] px-1.5 py-0.5 hover:bg-destructive/20 hover:text-destructive transition"
                        title="Revoke"
                      >
                        {r}
                        <X className="h-3 w-3 opacity-60 group-hover:opacity-100" />
                      </button>
                    ))}
                  </div>
                  <AddRoleControl
                    existing={u.roles}
                    onAdd={(role) =>
                      setRole.mutate({ user_id: u.user_id, role, grant: true })
                    }
                  />
                </td>
                <td className="p-3">
                  <span
                    className={
                      u.is_active
                        ? "inline-flex items-center gap-1 text-xs text-success"
                        : "inline-flex items-center gap-1 text-xs text-muted-foreground"
                    }
                  >
                    <span
                      className={
                        u.is_active
                          ? "h-1.5 w-1.5 rounded-full bg-success"
                          : "h-1.5 w-1.5 rounded-full bg-muted-foreground"
                      }
                    />
                    {u.is_active ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="p-3 text-right">
                  <Button
                    size="sm"
                    variant={u.is_active ? "outline" : "default"}
                    onClick={() =>
                      setActive.mutate({ user_id: u.user_id, is_active: !u.is_active })
                    }
                  >
                    {u.is_active ? (
                      <>
                        <UserX className="h-3.5 w-3.5 mr-1.5" /> Deactivate
                      </>
                    ) : (
                      <>
                        <UserCheck className="h-3.5 w-3.5 mr-1.5" /> Activate
                      </>
                    )}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AddRoleControl({
  existing,
  onAdd,
}: {
  existing: string[];
  onAdd: (role: (typeof ROLES)[number]) => void;
}) {
  const [val, setVal] = useState<string>("");
  const available = ROLES.filter((r) => !existing.includes(r));
  if (available.length === 0) return null;
  return (
    <div className="mt-2 flex items-center gap-1">
      <Select
        value={val}
        onValueChange={(v) => {
          setVal(v);
          onAdd(v as (typeof ROLES)[number]);
          setTimeout(() => setVal(""), 50);
        }}
      >
        <SelectTrigger className="h-7 text-xs w-[160px]">
          <Plus className="h-3 w-3 mr-1" />
          <SelectValue placeholder="Add role" />
        </SelectTrigger>
        <SelectContent>
          {available.map((r) => (
            <SelectItem key={r} value={r}>
              {r}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
