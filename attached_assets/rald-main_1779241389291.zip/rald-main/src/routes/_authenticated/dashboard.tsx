import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Users, ShieldCheck, ScrollText, Settings } from "lucide-react";
import { getMyProfile } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const fetchProfile = useServerFn(getMyProfile);
  const { data } = useQuery({ queryKey: ["me"], queryFn: () => fetchProfile() });

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <header>
        <h1 className="text-2xl font-semibold">
          Welcome{data?.profile?.full_name ? `, ${data.profile.full_name}` : ""}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          RALD identity workspace — phone-first, role-aware, audit-logged.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Account" value={data?.profile?.email ?? "—"} />
        <StatCard label="Roles" value={(data?.roles ?? []).join(", ") || "verified_user"} />
        <StatCard label="Status" value={data?.profile?.is_active ? "Active" : "Inactive"} />
        <StatCard
          label="Member since"
          value={data?.profile?.created_at ? new Date(data.profile.created_at).toLocaleDateString() : "—"}
        />
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card icon={<Users className="h-5 w-5" />} title="Identity">
          Phone-verified account. Manage profile details and linked sister apps.
        </Card>
        <Card icon={<ShieldCheck className="h-5 w-5" />} title="Security">
          Sessions secured via Supabase JWT. All sensitive actions are audit-logged.
        </Card>
        {data?.isAdmin && (
          <>
            <Card icon={<ScrollText className="h-5 w-5" />} title="Audit logs">
              Inspect every login, role change and configuration update.
            </Card>
            <Card icon={<Settings className="h-5 w-5" />} title="OTP provider">
              Switch between Termii / Twilio / Africa's Talking without redeploying.
            </Card>
          </>
        )}
      </section>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
      <div className="mt-2 text-sm font-medium truncate">{value}</div>
    </div>
  );
}

function Card({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center gap-2 text-foreground">
        <div className="h-8 w-8 rounded bg-primary/15 text-primary flex items-center justify-center">
          {icon}
        </div>
        <div className="font-medium">{title}</div>
      </div>
      <p className="text-sm text-muted-foreground mt-3">{children}</p>
    </div>
  );
}
