import { createFileRoute, Link, Outlet, useMatchRoute } from "@tanstack/react-router";
import { Wallet, History, HandCoins } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/wallet")({
  component: WalletLayout,
});

type NavItem = {
  to: string;
  label: string;
  icon: LucideIcon;
  /** When false, only match this exact path (not sub-paths). */
  fuzzy?: boolean;
};

const NAV: NavItem[] = [
  { to: "/wallet", label: "Overview", icon: Wallet, fuzzy: false },
  { to: "/wallet/transactions", label: "Transactions", icon: History },
  { to: "/wallet/escrow", label: "Escrow", icon: HandCoins },
];

function WalletLayout() {
  const matchRoute = useMatchRoute();
  return (
    <div className="flex flex-col min-h-full">
      <div className="border-b border-border bg-card/50 px-8 pt-8 pb-0">
        <h1 className="text-2xl font-semibold mb-4">Wallet & Escrow</h1>
        <nav className="flex gap-1 -mb-px">
          {NAV.map(({ to, label, icon: Icon, fuzzy }) => {
            const active = matchRoute({ to: to as never, fuzzy: fuzzy ?? true });
            return (
              <Link
                key={to}
                to={to as never}
                className={cn(
                  "flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors",
                  active
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:border-border",
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="flex-1 p-8">
        <Outlet />
      </div>
    </div>
  );
}
