import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { Phone, ShieldCheck, ArrowRight, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";
import { requestPhoneOtp, verifyPhoneOtp } from "@/lib/auth-phone.functions";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { session, loading } = useSession();
  const requestOtp = useServerFn(requestPhoneOtp);
  const verifyOtp = useServerFn(verifyPhoneOtp);

  const [step, setStep] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [normalized, setNormalized] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && session) navigate({ to: "/dashboard" });
  }, [loading, session, navigate]);

  async function onRequest(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await requestOtp({ data: { phone } });
      if (!res.ok) {
        toast.error(res.error ?? "Failed to send code");
        return;
      }
      setNormalized(res.phone ?? phone);
      setStep("code");
      toast.success("Code sent. Check your messages.");
    } finally {
      setBusy(false);
    }
  }

  async function onVerify(e: React.FormEvent) {
    e.preventDefault();
    if (code.length !== 6) return;
    setBusy(true);
    try {
      const res = await verifyOtp({ data: { phone: normalized, code } });
      if (!res.ok || !res.email || !res.password) {
        toast.error(res.error ?? "Verification failed");
        return;
      }
      const { error } = await supabase.auth.signInWithPassword({
        email: res.email,
        password: res.password,
      });
      if (error) {
        toast.error(error.message);
        return;
      }
      toast.success("Signed in");
      navigate({ to: "/dashboard" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex">
      {/* Left: brand */}
      <aside className="hidden lg:flex flex-col justify-between p-12 w-1/2 bg-sidebar border-r border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-md bg-primary flex items-center justify-center text-primary-foreground font-bold">
            R
          </div>
          <div>
            <div className="text-sm font-semibold tracking-wide">RALD</div>
            <div className="text-xs text-muted-foreground">
              Root Authentication & Login Directory
            </div>
          </div>
        </div>

        <div className="space-y-6 max-w-md">
          <h1 className="text-4xl font-semibold leading-tight">
            Phone-first identity for the OstLoop ecosystem.
          </h1>
          <p className="text-muted-foreground">
            Nigeria-first authentication, role-based access, API keys, wallet ledger
            and escrow — engineered for enterprise extensibility.
          </p>
          <div className="grid grid-cols-3 gap-4 pt-6">
            <Feature icon={<Phone className="h-4 w-4" />} label="Phone OTP" />
            <Feature icon={<ShieldCheck className="h-4 w-4" />} label="RBAC" />
            <Feature icon={<KeyRound className="h-4 w-4" />} label="API keys" />
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          auth.ostloop.name.ng · Cloudflare Edge
        </div>
      </aside>

      {/* Right: form */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-8">
          <div className="lg:hidden flex items-center gap-3">
            <div className="h-9 w-9 rounded-md bg-primary flex items-center justify-center text-primary-foreground font-bold">
              R
            </div>
            <div className="text-sm font-semibold">RALD</div>
          </div>

          {step === "phone" ? (
            <form onSubmit={onRequest} className="space-y-6">
              <div>
                <h2 className="text-2xl font-semibold">Sign in</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Enter your phone number to receive a verification code.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone number</Label>
                <Input
                  id="phone"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  placeholder="+234 801 234 5678"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Nigerian numbers default to +234. International numbers must include
                  the country code.
                </p>
              </div>
              <Button type="submit" className="w-full" disabled={busy || phone.length < 6}>
                {busy ? "Sending..." : "Send verification code"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>
          ) : (
            <form onSubmit={onVerify} className="space-y-6">
              <div>
                <h2 className="text-2xl font-semibold">Enter code</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  We sent a 6-digit code to <span className="text-foreground">{normalized}</span>.
                </p>
              </div>
              <div className="flex justify-center">
                <InputOTP maxLength={6} value={code} onChange={setCode}>
                  <InputOTPGroup>
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <InputOTPSlot key={i} index={i} />
                    ))}
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <Button type="submit" className="w-full" disabled={busy || code.length !== 6}>
                {busy ? "Verifying..." : "Verify & sign in"}
              </Button>
              <button
                type="button"
                onClick={() => {
                  setStep("phone");
                  setCode("");
                }}
                className="w-full text-xs text-muted-foreground hover:text-foreground"
              >
                ← Use a different phone number
              </button>
            </form>
          )}
        </div>
      </main>
    </div>
  );
}

function Feature({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="rounded-md border border-sidebar-border bg-sidebar-accent/40 p-3">
      <div className="h-7 w-7 rounded bg-primary/15 text-primary flex items-center justify-center">
        {icon}
      </div>
      <div className="mt-2 text-xs font-medium">{label}</div>
    </div>
  );
}
