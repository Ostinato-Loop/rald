import { createFileRoute, Link, Outlet, useNavigate, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import {
  LayoutDashboard,
  Users,
  ShieldCheck,
  KeyRound,
  Wallet,
  HandCoins,
  Settings,
  ScrollText,
  LogOut,
  Boxes,
  AppWindow,
  BarChart2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";
import { getMyProfile } from "@/lib/admin.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const { session, loading } = useSession();
  const navigate = useNavigate();
  const router = useRouter();
  const fetchProfile = useServerFn(getMyProfile);

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/login" });
  }, [loading, session, navigate]);

  const { data: me } = useQuery({
    queryKey: ["me", session?.user?.id],
    queryFn: () => fetchProfile(),
    enabled: Boolean(session),
  });

  if (loading || !session) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground text-sm">
        Loading…
      </div>
    );
  }

  const isAdmin = me?.isAdmin ?? false;
  const phone = (session.user.user_metadata as { phone?: string })?.phone ?? session.user.email;

  async function signOut() {
    await supabase.auth.signOut();
    router.invalidate();
    navigate({ to: "/login" });
  }

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="w-60 shrink-0 border-r border-sidebar-border bg-sidebar flex flex-col">
        <div className="p-4 border-b border-sidebar-border flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
            R
          </div>
          <div>
            <div className="text-sm font-semibold leading-tight">RALD</div>
            <div className="text-[10px] text-muted-foreground">Identity Console</div>
          </div>
        </div>

        <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
          <NavSection label="Workspace" />
          <NavItem to="/dashboard" icon={<LayoutDashboard className="h-4 w-4" />} label="Dashboard" />
          <NavItem to="/profile" icon={<Users className="h-4 w-4" />} label="My profile" />

          <NavSection label="Developer" />
          <NavItem to="/developer" icon={<Boxes className="h-4 w-4" />} label="Overview" />
          <NavItem to="/developer/apps" icon={<AppWindow className="h-4 w-4" />} label="Apps" />
          <NavItem to="/developer/api-keys" icon={<KeyRound className="h-4 w-4" />} label="API Keys" />
          <NavItem to="/developer/logs" icon={<ScrollText className="h-4 w-4" />} label="Logs" />
          <NavItem to="/developer/usage" icon={<BarChart2 className="h-4 w-4" />} label="Usage" />

          <NavSection label="Finance" />
          <NavItem to="/wallet" icon={<Wallet className="h-4 w-4" />} label="Wallet" />
          <NavItem to="/wallet/transactions" icon={<BarChart2 className="h-4 w-4" />} label="Transactions" />
          <NavItem to="/wallet/escrow" icon={<HandCoins className="h-4 w-4" />} label="Escrow" />

          {isAdmin && (
            <>
              <NavSection label="Admin" />
              <NavItem to="/admin/users" icon={<Users className="h-4 w-4" />} label="Users & roles" />
              <NavItem to="/admin/audit" icon={<ScrollText className="h-4 w-4" />} label="Audit logs" />
              <NavItem to="/admin/otp" icon={<Settings className="h-4 w-4" />} label="OTP provider" />
              <NavItem to="/admin/health" icon={<ShieldCheck className="h-4 w-4" />} label="System health" />
            </>
          )}
        </nav>

        <div className="p-3 border-t border-sidebar-border space-y-2">
          <div className="text-xs">
            <div className="font-medium truncate">{me?.profile?.full_name ?? "Unnamed"}</div>
            <div className="text-muted-foreground truncate">{phone}</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {(me?.roles ?? []).map((r) => (
                <span key={r} className="px-1.5 py-0.5 rounded bg-primary/15 text-primary text-[10px] font-medium">
                  {r}
                </span>
              ))}
            </div>
          </div>
          <button
            onClick={signOut}
            className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-muted-foreground hover:bg-sidebar-accent hover:text-foreground transition"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}

function NavSection({ label }: { label: string }) {
  return (
    <div className="px-2 pt-3 pb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
      {label}
    </div>
  );
}

function NavItem({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-2 px-2 py-1.5 rounded-md text-sm text-sidebar-foreground hover:bg-sidebar-accent transition"
      activeProps={{ className: "bg-sidebar-accent text-foreground" }}
    >
      {icon}
      {label}
    </Link>
  );
}
