import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { randomBytes } from "crypto";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { recordAudit } from "./auth-helpers.server";

// ─── Wallet ───────────────────────────────────────────────────────────────

export const getOrCreateWallet = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: existing } = await supabaseAdmin
      .from("rald_wallets")
      .select("*")
      .eq("user_id", context.userId)
      .eq("currency", "NGN")
      .maybeSingle();

    if (existing) return { wallet: existing };

    // Auto-create NGN wallet on first access
    const { data: wallet, error } = await supabaseAdmin
      .from("rald_wallets")
      .insert({ user_id: context.userId, currency: "NGN", balance_minor: 0, pending_minor: 0, locked_minor: 0 })
      .select("*")
      .single();

    if (error) throw new Error(error.message);
    await recordAudit(context.userId, "wallet.created", "wallet", wallet.id, { currency: "NGN" });
    return { wallet };
  });

export const listTransactions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      limit: z.number().int().min(1).max(100).default(50),
      offset: z.number().int().min(0).default(0),
      type: z.string().optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: wallet } = await supabaseAdmin
      .from("rald_wallets")
      .select("id")
      .eq("user_id", context.userId)
      .eq("currency", "NGN")
      .maybeSingle();

    if (!wallet) return { transactions: [], total: 0 };

    let q = supabaseAdmin
      .from("rald_wallet_transactions")
      .select("*", { count: "exact" })
      .eq("wallet_id", wallet.id)
      .order("created_at", { ascending: false })
      .range(data.offset, data.offset + data.limit - 1);

    if (data.type) q = q.eq("type", data.type) as typeof q;

    const { data: txns, count, error } = await q;
    if (error) throw new Error(error.message);
    return { transactions: txns ?? [], total: count ?? 0 };
  });

// ─── Escrow ────────────────────────────────────────────────────────────────

export const listEscrows = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await supabaseAdmin
      .from("rald_escrow")
      .select("*, escrow_txns:rald_escrow_transactions(id, action, notes, created_at)")
      .or(`buyer_id.eq.${context.userId},seller_id.eq.${context.userId}`)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { escrows: data ?? [] };
  });

export const createEscrow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      sellerId: z.string().uuid(),
      amountNaira: z.number().positive().max(10_000_000),
      title: z.string().trim().min(3).max(200),
      description: z.string().trim().max(1000).optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const amountMinor = Math.round(data.amountNaira * 100);

    // Verify buyer has sufficient balance
    const { data: wallet } = await supabaseAdmin
      .from("rald_wallets")
      .select("id, balance_minor")
      .eq("user_id", context.userId)
      .eq("currency", "NGN")
      .maybeSingle();

    if (!wallet || wallet.balance_minor < amountMinor) {
      throw new Error("Insufficient wallet balance");
    }

    // Create escrow + lock funds atomically via DB function
    const ref = randomBytes(8).toString("hex").toUpperCase();
    const { data: escrow, error } = await supabaseAdmin
      .from("rald_escrow")
      .insert({
        buyer_id: context.userId,
        seller_id: data.sellerId,
        amount_minor: amountMinor,
        currency: "NGN",
        status: "pending",
        title: data.title,
        description: data.description ?? null,
        metadata: { reference: ref } as never,
      })
      .select("id, title, amount_minor, status, created_at")
      .single();

    if (error) throw new Error(error.message);

    // Lock funds
    await supabaseAdmin
      .from("rald_wallets")
      .update({
        balance_minor: wallet.balance_minor - amountMinor,
        locked_minor: amountMinor,
      })
      .eq("id", wallet.id);

    // Record escrow transaction log
    await supabaseAdmin.from("rald_escrow_transactions").insert({
      escrow_id: escrow.id,
      actor_id: context.userId,
      action: "created",
      notes: `Escrow created for ₦${data.amountNaira.toLocaleString()}`,
    });

    await recordAudit(context.userId, "escrow.created", "escrow", escrow.id, { amount_minor: amountMinor, seller_id: data.sellerId });
    return { escrow };
  });

export const releaseEscrow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ escrowId: z.string().uuid(), notes: z.string().max(500).optional() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: escrow, error: fetchErr } = await supabaseAdmin
      .from("rald_escrow")
      .select("*")
      .eq("id", data.escrowId)
      .eq("buyer_id", context.userId)
      .eq("status", "pending")
      .single();

    if (fetchErr || !escrow) throw new Error("Escrow not found or already settled");

    // Get seller wallet
    const { data: sellerWallet } = await supabaseAdmin
      .from("rald_wallets")
      .select("id, balance_minor")
      .eq("user_id", escrow.seller_id)
      .eq("currency", "NGN")
      .maybeSingle();

    if (!sellerWallet) throw new Error("Seller has no NGN wallet");

    // Release: unlock buyer + credit seller
    const [{ data: buyerWallet }] = await Promise.all([
      supabaseAdmin.from("rald_wallets").select("id, locked_minor").eq("user_id", context.userId).eq("currency", "NGN").single(),
    ]);

    await Promise.all([
      supabaseAdmin.from("rald_wallets")
        .update({ locked_minor: Math.max(0, (buyerWallet?.locked_minor ?? 0) - escrow.amount_minor) })
        .eq("user_id", context.userId),
      supabaseAdmin.from("rald_wallets")
        .update({ balance_minor: sellerWallet.balance_minor + escrow.amount_minor })
        .eq("id", sellerWallet.id),
      supabaseAdmin.from("rald_escrow")
        .update({ status: "released", updated_at: new Date().toISOString() })
        .eq("id", data.escrowId),
      supabaseAdmin.from("rald_escrow_transactions").insert({
        escrow_id: data.escrowId,
        actor_id: context.userId,
        action: "released",
        notes: data.notes ?? "Released by buyer",
      }),
    ]);

    await recordAudit(context.userId, "escrow.released", "escrow", data.escrowId, { amount_minor: escrow.amount_minor });
    return { ok: true };
  });

export const disputeEscrow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ escrowId: z.string().uuid(), reason: z.string().trim().min(10).max(1000) }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await supabaseAdmin
      .from("rald_escrow")
      .update({ status: "disputed", updated_at: new Date().toISOString() })
      .eq("id", data.escrowId)
      .or(`buyer_id.eq.${context.userId},seller_id.eq.${context.userId}`)
      .eq("status", "pending");
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("rald_escrow_transactions").insert({
      escrow_id: data.escrowId,
      actor_id: context.userId,
      action: "disputed",
      notes: data.reason,
    });

    await recordAudit(context.userId, "escrow.disputed", "escrow", data.escrowId, { reason: data.reason });
    return { ok: true };
  });
