import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { randomBytes, createHash } from "crypto";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { recordAudit } from "./auth-helpers.server";

// ─── Helpers ───────────────────────────────────────────────────────────────

function generateApiKey(prefix: string): { key: string; keyHash: string; keyPrefix: string } {
  const secret = randomBytes(32).toString("hex");
  const key = `${prefix}_${secret}`;
  const keyHash = createHash("sha256").update(key).digest("hex");
  const keyPrefix = key.slice(0, prefix.length + 9); // prefix + _ + 8 chars
  return { key, keyHash, keyPrefix };
}

function generateClientSecret(): { secret: string; secretHash: string } {
  const secret = randomBytes(32).toString("hex");
  const secretHash = createHash("sha256").update(secret).digest("hex");
  return { secret, secretHash };
}

// ─── API Keys ─────────────────────────────────────────────────────────────

export const listApiKeys = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await supabaseAdmin
      .from("rald_api_keys")
      .select(
        "id, name, prefix, environment, scopes, last_used_at, expires_at, revoked_at, created_at, app_id",
      )
      .eq("user_id", context.userId)
      .is("revoked_at", null)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { keys: data ?? [] };
  });

export const createApiKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        name: z.string().trim().min(1).max(80),
        environment: z.enum(["test", "live"]),
        scopes: z.array(z.string()).min(1).max(20),
        expiresInDays: z.number().int().min(1).max(365).optional(),
        appId: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const envPrefix = data.environment === "live" ? "rald_live" : "rald_test";
    const { key, keyHash, keyPrefix } = generateApiKey(envPrefix);
    const expiresAt = data.expiresInDays
      ? new Date(Date.now() + data.expiresInDays * 86400_000).toISOString()
      : null;

    const { data: row, error } = await supabaseAdmin
      .from("rald_api_keys")
      .insert({
        user_id: context.userId,
        app_id: data.appId ?? null,
        name: data.name,
        prefix: keyPrefix,
        key_hash: keyHash,
        environment: data.environment,
        scopes: data.scopes as never,
        expires_at: expiresAt,
      })
      .select("id, name, prefix, environment, scopes, expires_at, created_at")
      .single();

    if (error) throw new Error(error.message);
    await recordAudit(context.userId, "api_key.created", "api_key", row.id, {
      name: data.name,
      environment: data.environment,
    });

    // Return the full key ONCE — it cannot be retrieved again
    return { ...row, key };
  });

export const revokeApiKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ keyId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await supabaseAdmin
      .from("rald_api_keys")
      .update({ revoked_at: new Date().toISOString() })
      .eq("id", data.keyId)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    await recordAudit(context.userId, "api_key.revoked", "api_key", data.keyId, {});
    return { ok: true };
  });

export const rotateApiKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ keyId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    // Fetch existing key info
    const { data: existing, error: fetchErr } = await supabaseAdmin
      .from("rald_api_keys")
      .select("*")
      .eq("id", data.keyId)
      .eq("user_id", context.userId)
      .is("revoked_at", null)
      .single();
    if (fetchErr || !existing) throw new Error("Key not found");

    // Revoke old key
    await supabaseAdmin
      .from("rald_api_keys")
      .update({ revoked_at: new Date().toISOString() })
      .eq("id", data.keyId);

    // Create replacement
    const envPrefix = existing.environment === "live" ? "rald_live" : "rald_test";
    const { key, keyHash, keyPrefix } = generateApiKey(envPrefix);

    const { data: row, error } = await supabaseAdmin
      .from("rald_api_keys")
      .insert({
        user_id: context.userId,
        app_id: existing.app_id,
        name: existing.name + " (rotated)",
        prefix: keyPrefix,
        key_hash: keyHash,
        environment: existing.environment,
        scopes: existing.scopes,
        expires_at: existing.expires_at,
      })
      .select("id, name, prefix, environment, scopes, expires_at, created_at")
      .single();

    if (error) throw new Error(error.message);
    await recordAudit(context.userId, "api_key.rotated", "api_key", row.id, {
      replaced: data.keyId,
    });
    return { ...row, key };
  });

// ─── Sister Apps ──────────────────────────────────────────────────────────

export const listApps = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await supabaseAdmin
      .from("rald_sister_apps")
      .select(
        "id, name, description, client_id, scopes, callback_urls, webhook_url, is_active, created_at",
      )
      .eq("owner_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { apps: data ?? [] };
  });

export const createApp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        name: z.string().trim().min(1).max(100),
        description: z.string().trim().max(500).optional(),
        callbackUrls: z.array(z.string().url()).min(1).max(10),
        webhookUrl: z.string().url().optional(),
        scopes: z.array(z.string()).min(1),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const clientId = `app_${randomBytes(16).toString("hex")}`;
    const { secret: clientSecret, secretHash } = generateClientSecret();

    const { data: row, error } = await supabaseAdmin
      .from("rald_sister_apps")
      .insert({
        name: data.name,
        description: data.description ?? null,
        client_id: clientId,
        client_secret_hash: secretHash,
        scopes: data.scopes as never,
        callback_urls: data.callbackUrls as never,
        webhook_url: data.webhookUrl ?? null,
        is_active: true,
        owner_id: context.userId,
      })
      .select("id, name, client_id, is_active, created_at")
      .single();

    if (error) throw new Error(error.message);
    await recordAudit(context.userId, "app.created", "sister_app", row.id, {
      name: data.name,
    });
    return { ...row, clientSecret };
  });

export const toggleApp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ appId: z.string().uuid(), isActive: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await supabaseAdmin
      .from("rald_sister_apps")
      .update({ is_active: data.isActive })
      .eq("id", data.appId)
      .eq("owner_id", context.userId);
    if (error) throw new Error(error.message);
    await recordAudit(
      context.userId,
      data.isActive ? "app.enabled" : "app.disabled",
      "sister_app",
      data.appId,
      {},
    );
    return { ok: true };
  });

// ─── API Usage Logs ───────────────────────────────────────────────────────

export const listApiLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        limit: z.number().int().min(1).max(200).default(50),
        keyId: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    let q = supabaseAdmin
      .from("rald_api_logs")
      .select("id, api_key_id, endpoint, method, status_code, duration_ms, ip_address, created_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(data.limit);

    if (data.keyId) q = q.eq("api_key_id", data.keyId) as typeof q;

    const { data: logs, error } = await q;
    if (error) throw new Error(error.message);
    return { logs: logs ?? [] };
  });

export const getUsageStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const since = new Date(Date.now() - 30 * 86400_000).toISOString();
    const { data: logs } = await supabaseAdmin
      .from("rald_api_logs")
      .select("status_code, duration_ms, created_at")
      .eq("user_id", context.userId)
      .gte("created_at", since);

    const total = logs?.length ?? 0;
    // status_code can be null in the DB schema; treat null as a server error (≥400)
    const success = logs?.filter((l) => (l.status_code ?? 999) < 400).length ?? 0;
    const avgLatency =
      total > 0
        ? Math.round((logs ?? []).reduce((s, l) => s + (l.duration_ms ?? 0), 0) / total)
        : 0;
    const errors = total - success;

    return {
      total,
      success,
      errors,
      avgLatency,
      successRate: total > 0 ? (success / total) * 100 : 100,
    };
  });
