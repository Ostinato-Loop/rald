import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { recordAudit } from "./auth-helpers.server";

const ROLES = [
  "super_admin",
  "admin",
  "moderator",
  "developer",
  "verified_user",
  "business",
  "finance_admin",
] as const;
type RaldRole = (typeof ROLES)[number];

async function assertAdmin(userId: string): Promise<void> {
  const { data, error } = await supabaseAdmin.rpc("rald_is_admin", { _user_id: userId });
  if (error || !data) throw new Error("Forbidden: admin role required");
}

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const [{ data: profile }, { data: roles }] = await Promise.all([
      supabaseAdmin.from("rald_profiles").select("*").eq("user_id", userId).maybeSingle(),
      supabaseAdmin.from("rald_user_roles").select("role").eq("user_id", userId),
    ]);
    const { data: isAdmin } = await supabaseAdmin.rpc("rald_is_admin", { _user_id: userId });
    return {
      profile,
      roles: (roles ?? []).map((r) => r.role as string),
      isAdmin: Boolean(isAdmin),
    };
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        full_name: z.string().trim().max(120).nullable().optional(),
        avatar_url: z.string().url().max(500).nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await supabaseAdmin
      .from("rald_profiles")
      .update({
        full_name: data.full_name ?? null,
        avatar_url: data.avatar_url ?? null,
      })
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminListUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        search: z.string().trim().max(200).optional(),
        limit: z.number().int().min(1).max(100).default(50),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);

    let q = supabaseAdmin
      .from("rald_profiles")
      .select("user_id, email, full_name, avatar_url, is_active, created_at, last_seen_at")
      .order("created_at", { ascending: false })
      .limit(data.limit);

    if (data.search) {
      q = q.or(`email.ilike.%${data.search}%,full_name.ilike.%${data.search}%`);
    }

    const { data: profiles, error } = await q;
    if (error) throw new Error(error.message);

    const userIds = (profiles ?? []).map((p) => p.user_id);
    const { data: roleRows } = userIds.length
      ? await supabaseAdmin.from("rald_user_roles").select("user_id, role").in("user_id", userIds)
      : { data: [] as { user_id: string; role: string }[] };

    const rolesByUser = new Map<string, string[]>();
    for (const r of roleRows ?? []) {
      const arr = rolesByUser.get(r.user_id) ?? [];
      arr.push(r.role as string);
      rolesByUser.set(r.user_id, arr);
    }

    return {
      users: (profiles ?? []).map((p) => ({
        ...p,
        roles: rolesByUser.get(p.user_id) ?? [],
      })),
    };
  });

export const adminSetUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        user_id: z.string().uuid(),
        role: z.enum(ROLES),
        grant: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);

    if (data.grant) {
      const { error } = await supabaseAdmin
        .from("rald_user_roles")
        .upsert(
          { user_id: data.user_id, role: data.role as RaldRole },
          { onConflict: "user_id,role" },
        );
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin
        .from("rald_user_roles")
        .delete()
        .eq("user_id", data.user_id)
        .eq("role", data.role);
      if (error) throw new Error(error.message);
    }

    await recordAudit(context.userId, data.grant ? "role.granted" : "role.revoked", "user", data.user_id, {
      role: data.role,
    });
    return { ok: true };
  });

export const adminSetUserActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ user_id: z.string().uuid(), is_active: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { error } = await supabaseAdmin
      .from("rald_profiles")
      .update({ is_active: data.is_active })
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    await recordAudit(context.userId, data.is_active ? "user.activated" : "user.deactivated", "user", data.user_id);
    return { ok: true };
  });

export const adminListAuditLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        action: z.string().trim().max(100).optional(),
        limit: z.number().int().min(1).max(200).default(100),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    let q = supabaseAdmin
      .from("rald_audit_logs")
      .select("id, action, actor_id, resource_type, resource_id, metadata, created_at")
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.action) q = q.ilike("action", `%${data.action}%`);
    const { data: logs, error } = await q;
    if (error) throw new Error(error.message);
    return { logs: logs ?? [] };
  });

export const adminGetOtpProvider = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { data } = await supabaseAdmin
      .from("rald_settings")
      .select("value, updated_at")
      .eq("key", "otp_provider")
      .maybeSingle();
    const v = (data?.value ?? {}) as Record<string, unknown>;
    return {
      provider: String(v.provider ?? "termii"),
      enabled: v.enabled !== false,
      sender_id: String(v.sender_id ?? ""),
      api_key_set: Boolean(v.api_key && String(v.api_key).length > 0),
      updated_at: data?.updated_at ?? null,
    };
  });

export const adminSetOtpProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        provider: z.enum(["termii", "twilio", "africastalking"]),
        enabled: z.boolean(),
        sender_id: z.string().trim().min(1).max(20),
        api_key: z.string().trim().max(500).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);

    // Preserve existing api_key if user didn't enter a new one
    const { data: existing } = await supabaseAdmin
      .from("rald_settings")
      .select("value")
      .eq("key", "otp_provider")
      .maybeSingle();
    const prevKey = (existing?.value as Record<string, unknown> | null)?.api_key as string | undefined;

    const value = {
      provider: data.provider,
      enabled: data.enabled,
      sender_id: data.sender_id,
      api_key: data.api_key && data.api_key.length > 0 ? data.api_key : prevKey ?? "",
    };

    const { error } = await supabaseAdmin
      .from("rald_settings")
      .upsert(
        { key: "otp_provider", value, updated_by: context.userId, updated_at: new Date().toISOString() },
        { onConflict: "key" },
      );
    if (error) throw new Error(error.message);

    await recordAudit(context.userId, "otp_provider.updated", "settings", "otp_provider", {
      provider: data.provider,
      enabled: data.enabled,
      api_key_changed: Boolean(data.api_key && data.api_key.length > 0),
    });
    return { ok: true };
  });
