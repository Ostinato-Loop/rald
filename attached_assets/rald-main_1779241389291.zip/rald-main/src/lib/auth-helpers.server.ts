// Server-only helpers for phone OTP auth + Termii integration.
import { createHash, randomInt, createHmac } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export function normalizePhone(input: string): string {
  const cleaned = input.replace(/[^\d+]/g, "");
  if (cleaned.startsWith("+")) return cleaned;
  // Default to Nigeria (+234) for 10/11-digit local numbers
  if (cleaned.startsWith("0")) return "+234" + cleaned.slice(1);
  if (cleaned.length === 10) return "+234" + cleaned;
  return "+" + cleaned;
}

export function isValidPhone(phone: string): boolean {
  return /^\+\d{10,15}$/.test(phone);
}

export function hashCode(phone: string, code: string): string {
  return createHash("sha256").update(`${phone}:${code}`).digest("hex");
}

export function generateOtpCode(): string {
  return randomInt(100000, 1000000).toString();
}

export function phoneToEmail(phone: string): string {
  // Synthetic email so we can use Supabase magiclink to mint a session
  return `${phone.replace("+", "")}@phone.rald.local`;
}

export function derivePassword(phone: string): string {
  const secret = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createHmac("sha256", secret).update(`rald:${phone}`).digest("hex");
}

export async function getOtpProviderConfig(): Promise<{
  provider: string;
  enabled: boolean;
  sender_id: string;
  api_key: string;
}> {
  const { data } = await supabaseAdmin
    .from("rald_settings")
    .select("value")
    .eq("key", "otp_provider")
    .maybeSingle();

  const v = (data?.value ?? {}) as Record<string, unknown>;
  return {
    provider: String(v.provider ?? "termii"),
    enabled: v.enabled !== false,
    sender_id: String(v.sender_id ?? process.env.TERMII_SENDER_ID ?? "RALD"),
    api_key: String(v.api_key ?? process.env.TERMII_API_KEY ?? ""),
  };
}

export async function sendOtpSms(phone: string, code: string): Promise<{ ok: boolean; error?: string }> {
  const cfg = await getOtpProviderConfig();
  if (!cfg.enabled) return { ok: false, error: "OTP provider disabled" };

  const message = `Your RALD verification code is ${code}. Expires in 5 minutes.`;

  if (cfg.provider === "termii") {
    const apiKey = cfg.api_key || process.env.TERMII_API_KEY;
    if (!apiKey) {
      // Dev fallback — log code so testing works without provider configured
      console.warn(`[RALD OTP — DEV MODE] ${phone}: ${code}`);
      return { ok: true };
    }
    try {
      const res = await fetch("https://api.ng.termii.com/api/sms/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: phone.replace("+", ""),
          from: cfg.sender_id,
          sms: message,
          type: "plain",
          channel: "generic",
          api_key: apiKey,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
      if (!res.ok) {
        return { ok: false, error: String(json.message ?? `Termii error ${res.status}`) };
      }
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : "Network error" };
    }
  }

  console.warn(`[RALD OTP — provider ${cfg.provider} not implemented] ${phone}: ${code}`);
  return { ok: true };
}

export async function recordAudit(
  actorId: string | null,
  action: string,
  resourceType?: string,
  resourceId?: string,
  metadata: Record<string, unknown> = {},
): Promise<void> {
  await supabaseAdmin.from("rald_audit_logs").insert({
    actor_id: actorId,
    action,
    resource_type: resourceType ?? null,
    resource_id: resourceId ?? null,
    metadata: metadata as never,
  });
}
