import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  derivePassword,
  generateOtpCode,
  hashCode,
  isValidPhone,
  normalizePhone,
  phoneToEmail,
  recordAudit,
  sendOtpSms,
} from "./auth-helpers.server";

export const requestPhoneOtp = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ phone: z.string().min(6).max(20) }).parse(input))
  .handler(async ({ data }) => {
    const phone = normalizePhone(data.phone);
    if (!isValidPhone(phone)) {
      return { ok: false, error: "Invalid phone number" };
    }

    // Rate limit: max 5 codes per 10 min per phone
    const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const { count } = await supabaseAdmin
      .from("rald_phone_otps")
      .select("id", { count: "exact", head: true })
      .eq("phone", phone)
      .gte("created_at", tenMinAgo);

    if ((count ?? 0) >= 5) {
      return { ok: false, error: "Too many requests. Please wait a few minutes." };
    }

    const code = generateOtpCode();
    const code_hash = hashCode(phone, code);
    const expires_at = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    const { error } = await supabaseAdmin.from("rald_phone_otps").insert({
      phone,
      code_hash,
      expires_at,
    });
    if (error) return { ok: false, error: "Failed to create OTP" };

    const send = await sendOtpSms(phone, code);
    if (!send.ok) return { ok: false, error: send.error ?? "Failed to send SMS" };

    await recordAudit(null, "otp.requested", "phone", phone, { provider: "termii" });
    return { ok: true, phone };
  });

export const verifyPhoneOtp = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ phone: z.string().min(6).max(20), code: z.string().regex(/^\d{6}$/) }).parse(input),
  )
  .handler(async ({ data }) => {
    const phone = normalizePhone(data.phone);
    const code_hash = hashCode(phone, data.code);

    const { data: row } = await supabaseAdmin
      .from("rald_phone_otps")
      .select("id, expires_at, consumed_at, attempts")
      .eq("phone", phone)
      .eq("code_hash", code_hash)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!row) {
      await recordAudit(null, "otp.failed", "phone", phone, { reason: "no_match" });
      return { ok: false, error: "Invalid code" };
    }
    if (row.consumed_at) return { ok: false, error: "Code already used" };
    if (new Date(row.expires_at).getTime() < Date.now()) {
      return { ok: false, error: "Code expired" };
    }

    await supabaseAdmin
      .from("rald_phone_otps")
      .update({ consumed_at: new Date().toISOString() })
      .eq("id", row.id);

    // Ensure a Supabase auth user exists for this phone
    const email = phoneToEmail(phone);
    const password = derivePassword(phone);

    // Try to fetch existing by email
    const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
    let userId = list?.users.find((u) => u.email === email)?.id;

    if (!userId) {
      const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        phone,
        email_confirm: true,
        phone_confirm: true,
        user_metadata: { phone, source: "rald_phone_otp" },
      });
      if (createErr || !created.user) {
        return { ok: false, error: createErr?.message ?? "Failed to create user" };
      }
      userId = created.user.id;

      // Seed profile + default role (trigger isn't installed)
      await supabaseAdmin.from("rald_profiles").insert({
        user_id: userId,
        email,
        full_name: null,
        avatar_url: null,
      });
      await supabaseAdmin
        .from("rald_user_roles")
        .insert({ user_id: userId, role: "verified_user" });
      await supabaseAdmin.from("rald_wallets").insert({ user_id: userId, currency: "NGN" });
    } else {
      // Always re-sync password in case secret changed
      await supabaseAdmin.auth.admin.updateUserById(userId, { password });
    }

    await recordAudit(userId, "auth.login", "user", userId, { method: "phone_otp" });

    return { ok: true, email, password };
  });
