import { defineConfig } from "vite";
import { cloudflare } from "@cloudflare/vite-plugin";
import { TanStackRouterVite } from "@tanstack/router-plugin/vite";
import tsConfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [
    cloudflare(),
    TanStackRouterVite({
      target: "react",
      autoCodeSplitting: true,
    }),
    tsConfigPaths(),
  ],
  build: {
    target: "es2022",
  },
});
